# RedOS: запуск и типовые ошибки

## Правильный порядок

1. Распаковать ZIP.
2. В pgAdmin создать базу `V4`.
3. В базе `V4` выполнить `01_exam_v4_all_queries.sql`.
4. Перейти в приложение:

```bash
cd M4_Приложение
chmod +x run_redos.sh
./run_redos.sh
```

Вход:

```text
admin
admin
```

Приложение сначала пробует PostgreSQL. Если подключение не получилось, оно откроется в локальном режиме. Это запасной режим для демонстрации интерфейса.

## Ошибка: Connection refused

Причина: PostgreSQL не запущен на портах `5432` или `5433`.

Проверка:

```bash
pg_isready -h localhost -p 5432
pg_isready -h localhost -p 5433
```

Если PostgreSQL на другом порту, можно указать:

```bash
export PGPORT=ВАШ_ПОРТ
```

Но приложение все равно имеет локальный режим, поэтому интерфейс можно показать.

## Ошибка: database "V4" does not exist

Причина: база `V4` не создана.

Что делать в pgAdmin:

```text
Databases -> Create -> Database -> V4 -> Save
```

Потом открыть Query Tool именно в базе `V4` и выполнить:

```text
01_exam_v4_all_queries.sql
```

## Ошибка: password authentication failed

Причина: пароль PostgreSQL другой.

Можно указать пароль так:

```bash
export PGPASSWORD='ваш_пароль'
```

Потом снова:

```bash
python check_redos.py
python main.py
```

## Ошибка: no module named tkinter

Причина: в RedOS не установлен Tkinter.

Решение: попросить администратора поставить пакет:

```bash
sudo dnf install python3-tkinter
```

Если sudo нельзя, это должен сделать администратор площадки.

## Ошибка при установке Python-пакетов

В этом комплекте внешние Python-библиотеки не нужны. `Pillow` устанавливать не надо: капча работает через встроенный `tk.PhotoImage`.

Если кто-то все равно запустил `pip install -r requirements.txt`, это не страшно, файл зависимостей пустой по смыслу.

Основной запуск:

```bash
cd M4_Приложение
python3 check_redos.py
python3 main.py
```

## Ошибка: images/1.png not found

Причина: приложение запущено не из папки `M4_Приложение` или не распакованы картинки.

Что делать:

```bash
cd M4_Приложение
ls images
python3 main.py
```

В папке `images` должны быть `1.png`, `2.png`, `3.png`, `4.png`.

## Контроль готовности

```bash
cd M4_Приложение
chmod +x run_redos.sh
./run_redos.sh
```

Если PostgreSQL недоступен, приложение откроется в локальном режиме. Вход остается `admin/admin`.
