import os


APP_COMPANY = 'ООО "Два сеньора"'
DEFAULT_NEW_USER_PASSWORD = "12345"

DB_CONFIG = {
    "host": os.getenv("PGHOST", "localhost"),
    "dbname": os.getenv("PGDATABASE", "V4"),
    "user": os.getenv("PGUSER", "postgres"),
}

DB_PORTS = ["5432", "5433"]
DB_PASSWORDS = [os.getenv("PGPASSWORD")] if os.getenv("PGPASSWORD") else ["87654321"]

AUTH_ERROR_TEXT = "Вы ввели неверный логин или пароль. Пожалуйста проверьте ещё раз введенные данные"
BLOCKED_TEXT = "Вы заблокированы. Обратитесь к администратору"
AUTH_SUCCESS_TEXT = "Вы успешно авторизовались"
