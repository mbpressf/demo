import os
import runpy

runpy.run_path(os.path.join(os.path.dirname(__file__), "M4_Приложение", "main.py"), run_name="__main__")
