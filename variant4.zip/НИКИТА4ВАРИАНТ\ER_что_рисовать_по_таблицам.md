# ER-диаграмма по финальной простой схеме

Таблицы:

- `customers`
- `materials`
- `products`
- `specifications`
- `orders`
- `order_items`
- `users`

Связи:

- `customers.id` -> `orders.customer_id`
- `customers.id` -> `orders.executor_id`
- `orders.id` -> `order_items.order_id`
- `products.id` -> `order_items.product_id`
- `products.id` -> `specifications.product_id`
- `materials.id` -> `specifications.material_id`

Таблица `specifications` связывает продукцию и материалы.
Таблица `users` нужна для модуля 4.
