-- Вариант 4. Модуль 2: загрузка данных.

BEGIN;

INSERT INTO customers (id, name, inn, address, phone, is_seller, is_buyer) VALUES
('000000000', 'ООО "Два сеньора"', NULL, 'адрес не указан в приложении', NULL, TRUE, FALSE),
('000000001', 'ООО "Поставка"', NULL, 'г.Пятигорск', '+79198634592', TRUE, TRUE),
('000000002', 'ООО "Кинотеатр Квант"', '26320045123', 'г. Железноводск, ул. Мира, 123', '+79884581555', TRUE, FALSE),
('000000008', 'ООО "Новый JDTO"', '26320045111', 'г. Железноводсу', '+79884581555', TRUE, FALSE),
('000000003', 'ООО "Ромашка"', '4140784214', 'г. Омск, ул. Строителей, 294', '+79882584546', FALSE, TRUE),
('000000009', 'ООО "Ипподром"', '5874045632', 'г. Уфа, ул. Набережная,  37', '+79627486389', TRUE, TRUE),
('000000010', 'ООО "Ассоль"', '2629011278', 'г. Калуга, ул. Пушкина, 94', '+79184572398', FALSE, TRUE);

-- Цены материалов взяты из "Расчет стоимости продукции.xlsx",
-- чтобы контрольный расчет себестоимости совпал с приложением: 468.50.
INSERT INTO materials (code, name, unit, price) VALUES
('НФ-00000009', 'Куриное яйцо', 'шт', 8.00),
('НФ-00000010', 'Майонез', 'кг', 150.00),
('НФ-00000011', 'Бекон', 'кг', 250.00),
('НФ-00000012', 'Тесто', 'шт', 200.00),
('НФ-00000013', 'Сыр чеддер', 'шт', 860.00),
('НФ-00000014', 'Сыр пармезан', 'шт', 890.00),
('НФ-00000015', 'Томаты черри', 'кг', 400.00);

INSERT INTO products (code, name, unit, price) VALUES
('НФ-00000002', 'Пицца "Пеперони" 33см.', 'шт', 850.00),
(NULL, 'Пицца "Маргарита" 33см.', 'шт', 710.00),
(NULL, 'Пицца "Гавайская" 30см.', 'шт', 420.00),
(NULL, 'Пицца "Морская" 30см.', 'шт', 640.00);

INSERT INTO specifications (product_id, material_id, quantity)
SELECT p.id, m.id, v.quantity
FROM (
    VALUES
        ('Пицца "Пеперони" 33см.', 'Куриное яйцо', 2.000::NUMERIC),
        ('Пицца "Пеперони" 33см.', 'Майонез', 0.030::NUMERIC),
        ('Пицца "Пеперони" 33см.', 'Бекон', 0.200::NUMERIC),
        ('Пицца "Пеперони" 33см.', 'Тесто', 0.500::NUMERIC),
        ('Пицца "Пеперони" 33см.', 'Сыр чеддер', 0.150::NUMERIC),
        ('Пицца "Пеперони" 33см.', 'Сыр пармезан', 0.100::NUMERIC),
        ('Пицца "Пеперони" 33см.', 'Томаты черри', 0.200::NUMERIC)
) AS v(product_name, material_name, quantity)
JOIN products p ON p.name = v.product_name
JOIN materials m ON m.name = v.material_name;

INSERT INTO orders (id, order_number, order_date, executor_id, customer_id, total_amount)
VALUES (1, '2', DATE '2025-06-06', '000000000', '000000002', 7660.00);

INSERT INTO order_items (order_id, product_id, quantity, unit, price, subtotal)
SELECT 1, p.id, v.quantity, 'шт', v.price, v.quantity * v.price
FROM (
    VALUES
        ('Пицца "Пеперони" 33см.', 4, 850.00::NUMERIC),
        ('Пицца "Маргарита" 33см.', 6, 710.00::NUMERIC)
) AS v(product_name, quantity, price)
JOIN products p ON p.name = v.product_name;

COMMIT;
