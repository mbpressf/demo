-- В pgAdmin надежнее создать базу V4 вручную:
-- Databases -> Create -> Database -> V4 -> Save.
-- Этот скрипт использовать только если Query Tool работает без транзакции.
SELECT pg_terminate_backend(pid)
FROM pg_stat_activity
WHERE datname = 'V4' AND pid <> pg_backend_pid();

DROP DATABASE IF EXISTS "V4";
CREATE DATABASE "V4";
