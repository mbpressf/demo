-- Вариант 4. Модуль 3: расчет полной материальной стоимости заказа покупателя.

WITH product_material_cost AS (
    SELECT
        s.product_id,
        SUM(s.quantity * m.price) AS material_cost_per_unit
    FROM specifications s
    JOIN materials m ON m.id = s.material_id
    GROUP BY s.product_id
),
order_material_cost AS (
    SELECT
        o.id AS order_id,
        o.order_number,
        o.order_date,
        c.name AS customer_name,
        p.name AS product_name,
        oi.quantity AS product_quantity,
        oi.subtotal AS product_sale_amount,
        COALESCE(pmc.material_cost_per_unit, 0) AS material_cost_per_unit,
        oi.quantity * COALESCE(pmc.material_cost_per_unit, 0) AS material_cost_total
    FROM orders o
    JOIN customers c ON c.id = o.customer_id
    JOIN order_items oi ON oi.order_id = o.id
    JOIN products p ON p.id = oi.product_id
    LEFT JOIN product_material_cost pmc ON pmc.product_id = p.id
)
SELECT
    order_id,
    order_number,
    order_date,
    customer_name,
    SUM(product_sale_amount) AS order_sale_total,
    SUM(material_cost_total) AS order_material_total
FROM order_material_cost
GROUP BY order_id, order_number, order_date, customer_name
ORDER BY order_id;

-- Контроль:
-- Пицца "Пеперони" 33см.: 468.50
-- 4 * 468.50 = 1874.00
