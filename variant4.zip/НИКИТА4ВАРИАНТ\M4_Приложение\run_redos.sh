#!/usr/bin/env bash
set -e

cd "$(dirname "$0")"

python3 check_redos.py
python3 main.py
