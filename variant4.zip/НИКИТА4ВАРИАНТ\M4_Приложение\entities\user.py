from dataclasses import dataclass


@dataclass(frozen=True)
class User:
    login: str
    role: str
    is_blocked: bool
