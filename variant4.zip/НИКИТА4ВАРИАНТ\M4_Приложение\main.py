import os
import sys
from tkinter import messagebox

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from entities.user_manager import UserManager
from forms.forms import LoginWindow


def main():
    UserManager.init_db()
    LoginWindow().mainloop()


if __name__ == "__main__":
    main()
