import os
import shutil
import sys
import tkinter

from config import DB_CONFIG, DB_PASSWORDS, DB_PORTS


def check_module(name):
    try:
        __import__(name)
        print(f"[OK] Python module: {name}")
        return True
    except Exception as exc:
        print(f"[FAIL] Python module: {name}: {exc}")
        return False


def check_postgres_connection():
    try:
        import psycopg2
    except Exception as exc:
        print(f"[WARN] psycopg2 is not installed: {exc}")
        print("[WARN] The app will use local fallback login: admin/admin")
        return False

    print(f"[INFO] DB host: {DB_CONFIG['host']}")
    print(f"[INFO] DB name: {DB_CONFIG['dbname']}")
    print(f"[INFO] DB user: {DB_CONFIG['user']}")
    print(f"[INFO] Ports to try: {', '.join(DB_PORTS)}")

    for port in DB_PORTS:
        for password in DB_PASSWORDS:
            try:
                conn = psycopg2.connect(**DB_CONFIG, port=port, password=password)
                with conn, conn.cursor() as cur:
                    cur.execute("SELECT current_database(), current_user")
                    db_name, db_user = cur.fetchone()
                    print(f"[OK] PostgreSQL connection: port={port}, database={db_name}, user={db_user}")
                    return True
            except Exception as exc:
                print(f"[FAIL] PostgreSQL port={port}: {exc}")
    return False


def main():
    ok = True
    print(f"[INFO] Python: {sys.version.split()[0]}")
    print(f"[INFO] tkinter: {tkinter.TkVersion}")
    print(f"[INFO] psql command: {shutil.which('psql') or 'not found'}")

    postgres_ok = check_postgres_connection()

    if not ok:
        print("\n[HELP] Typical RedOS fixes:")
        print("1. If tkinter is missing: ask admin to install python3-tkinter.")
        sys.exit(1)

    if postgres_ok:
        print("\n[OK] Environment is ready with PostgreSQL. Run: python main.py")
    else:
        print("\n[OK] Environment is ready in local fallback mode. Run: python main.py")
        print("[INFO] Login remains: admin/admin")


if __name__ == "__main__":
    main()
