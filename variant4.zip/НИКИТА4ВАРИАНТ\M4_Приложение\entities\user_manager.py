try:
    import psycopg2
except Exception:
    psycopg2 = None

import hashlib

from config import DB_CONFIG, DB_PASSWORDS, DB_PORTS, DEFAULT_NEW_USER_PASSWORD
from entities.user import User


class UserManager:
    use_local_storage = False
    local_users = {}
    last_db_error = ""

    @staticmethod
    def _hash_password(password):
        return "sha256:" + hashlib.sha256(password.encode("utf-8")).hexdigest()

    @staticmethod
    def _verify_password(password, password_hash):
        if password_hash.startswith("sha256:"):
            return UserManager._hash_password(password) == password_hash
        return password == password_hash

    @staticmethod
    def _ensure_local_admin():
        if "admin" not in UserManager.local_users:
            UserManager.local_users["admin"] = {
                "password_hash": UserManager._hash_password("admin"),
                "role": "admin",
                "is_blocked": False,
                "failed_attempts": 0,
            }

    @staticmethod
    def connect():
        if psycopg2 is None:
            raise RuntimeError("psycopg2 is not installed")

        errors = []
        for port in DB_PORTS:
            for password in DB_PASSWORDS:
                try:
                    return psycopg2.connect(**DB_CONFIG, port=port, password=password, connect_timeout=1)
                except Exception as exc:
                    errors.append(f"port {port}: {exc}")

        raise RuntimeError("\n".join(errors[-4:]))

    @staticmethod
    def init_db():
        try:
            with UserManager.connect() as conn, conn.cursor() as cur:
                cur.execute(
                    """
                    CREATE TABLE IF NOT EXISTS users (
                        login VARCHAR(50) PRIMARY KEY,
                        password_hash VARCHAR(120) NOT NULL,
                        role VARCHAR(20) NOT NULL DEFAULT 'user',
                        is_blocked BOOLEAN NOT NULL DEFAULT FALSE,
                        failed_attempts INTEGER NOT NULL DEFAULT 0,
                        CHECK (role IN ('admin', 'user')),
                        CHECK (failed_attempts >= 0)
                    )
                    """
                )
                cur.execute("SELECT 1 FROM users WHERE login = %s", ("admin",))
                if cur.fetchone() is None:
                    cur.execute(
                        """
                        INSERT INTO users (login, password_hash, role, is_blocked, failed_attempts)
                        VALUES (%s, %s, 'admin', FALSE, 0)
                        """,
                        ("admin", UserManager._hash_password("admin")),
                    )
                conn.commit()
            UserManager.use_local_storage = False
        except Exception as exc:
            UserManager.use_local_storage = True
            UserManager.last_db_error = str(exc)
            UserManager._ensure_local_admin()

    @staticmethod
    def authenticate(login, password, captcha_ok):
        if UserManager.use_local_storage:
            return UserManager._auth_local(login, password, captcha_ok)

        with UserManager.connect() as conn, conn.cursor() as cur:
            cur.execute(
                "SELECT password_hash, role, is_blocked FROM users WHERE login = %s",
                (login,),
            )
            row = cur.fetchone()
            if row is None:
                return "fail"

            password_hash, role, is_blocked = row
            if is_blocked:
                return "blocked"

            if captcha_ok and UserManager._verify_password(password, password_hash):
                cur.execute("UPDATE users SET failed_attempts = 0 WHERE login = %s", (login,))
                conn.commit()
                return role

            cur.execute(
                """
                UPDATE users
                SET failed_attempts = failed_attempts + 1,
                    is_blocked = failed_attempts + 1 >= 3
                WHERE login = %s
                RETURNING is_blocked
                """,
                (login,),
            )
            blocked_now = cur.fetchone()[0]
            conn.commit()
            return "blocked" if blocked_now else "fail"

    @staticmethod
    def _auth_local(login, password, captcha_ok):
        user = UserManager.local_users.get(login)
        if user is None:
            return "fail"
        if user["is_blocked"]:
            return "blocked"
        if captcha_ok and UserManager._verify_password(password, user["password_hash"]):
            user["failed_attempts"] = 0
            return user["role"]
        user["failed_attempts"] += 1
        if user["failed_attempts"] >= 3:
            user["is_blocked"] = True
            return "blocked"
        return "fail"

    @staticmethod
    def list_users():
        if UserManager.use_local_storage:
            UserManager._ensure_local_admin()
            return [
                User(login=login, role=data["role"], is_blocked=data["is_blocked"])
                for login, data in sorted(UserManager.local_users.items())
            ]

        with UserManager.connect() as conn, conn.cursor() as cur:
            cur.execute("SELECT login, role, is_blocked FROM users ORDER BY login")
            return [User(login=row[0], role=row[1], is_blocked=row[2]) for row in cur.fetchall()]

    @staticmethod
    def add_user(login):
        if UserManager.use_local_storage:
            if login in UserManager.local_users:
                return False
            UserManager.local_users[login] = {
                "password_hash": UserManager._hash_password(DEFAULT_NEW_USER_PASSWORD),
                "role": "user",
                "is_blocked": False,
                "failed_attempts": 0,
            }
            return True

        with UserManager.connect() as conn, conn.cursor() as cur:
            cur.execute("SELECT 1 FROM users WHERE login = %s", (login,))
            if cur.fetchone() is not None:
                return False
            cur.execute(
                """
                INSERT INTO users (login, password_hash, role, is_blocked, failed_attempts)
                VALUES (%s, %s, 'user', FALSE, 0)
                """,
                (login, UserManager._hash_password(DEFAULT_NEW_USER_PASSWORD)),
            )
            conn.commit()
            return True

    @staticmethod
    def set_role(login, role):
        if UserManager.use_local_storage:
            if login in UserManager.local_users:
                UserManager.local_users[login]["role"] = role
            return

        with UserManager.connect() as conn, conn.cursor() as cur:
            cur.execute("UPDATE users SET role = %s WHERE login = %s", (role, login))
            conn.commit()

    @staticmethod
    def unblock(login):
        if UserManager.use_local_storage:
            if login in UserManager.local_users:
                UserManager.local_users[login]["is_blocked"] = False
                UserManager.local_users[login]["failed_attempts"] = 0
            return

        with UserManager.connect() as conn, conn.cursor() as cur:
            cur.execute(
                "UPDATE users SET is_blocked = FALSE, failed_attempts = 0 WHERE login = %s",
                (login,),
            )
            conn.commit()
