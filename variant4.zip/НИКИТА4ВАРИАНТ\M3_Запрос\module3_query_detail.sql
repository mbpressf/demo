-- Детализация расчета модуля 3.

WITH product_material_cost AS (
    SELECT
        s.product_id,
        SUM(s.quantity * m.price) AS material_cost_per_unit
    FROM specifications s
    JOIN materials m ON m.id = s.material_id
    GROUP BY s.product_id
)
SELECT
    o.id AS order_id,
    p.name AS product_name,
    oi.quantity,
    oi.subtotal AS sale_amount,
    COALESCE(pmc.material_cost_per_unit, 0) AS material_cost_per_unit,
    oi.quantity * COALESCE(pmc.material_cost_per_unit, 0) AS material_cost_total
FROM orders o
JOIN order_items oi ON oi.order_id = o.id
JOIN products p ON p.id = oi.product_id
LEFT JOIN product_material_cost pmc ON pmc.product_id = p.id
ORDER BY o.id, p.name;
