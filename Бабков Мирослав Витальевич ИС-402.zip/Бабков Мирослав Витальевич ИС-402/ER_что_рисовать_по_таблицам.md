# ER-диаграмма по финальной простой схеме

Эта схема ближе к примеру решения и к формулировке задания. Лишние таблицы истории цен и производства не нужны.

## Таблицы

### customers

- `id` PK
- `name`
- `inn`
- `address`
- `phone`
- `is_seller`
- `is_buyer`

### materials

- `id` PK
- `code`
- `name`
- `unit`
- `price`

### products

- `id` PK
- `code`
- `name`
- `unit`
- `price`

### specifications

- `product_id` PK, FK -> `products.id`
- `material_id` PK, FK -> `materials.id`
- `quantity`

### orders

- `id` PK
- `order_number`
- `order_date`
- `executor_id` FK -> `customers.id`
- `customer_id` FK -> `customers.id`
- `total_amount`

### order_items

- `order_id` PK, FK -> `orders.id`
- `product_id` PK, FK -> `products.id`
- `quantity`
- `unit`
- `price`
- `subtotal`

### users

- `login` PK
- `password_hash`
- `role`
- `is_blocked`
- `failed_attempts`

## Связи

- `customers.id` -> `orders.customer_id`
- `customers.id` -> `orders.executor_id`
- `orders.id` -> `order_items.order_id`
- `products.id` -> `order_items.product_id`
- `products.id` -> `specifications.product_id`
- `materials.id` -> `specifications.material_id`

## Как объяснить

Продукция и материалы связаны отношением многие-ко-многим через таблицу `specifications`, потому что одна продукция состоит из нескольких материалов, а один материал может использоваться в разных продуктах.

Заказ покупателя разделен на `orders` и `order_items`, потому что у одного заказа может быть несколько строк продукции.

Таблица `users` нужна для модуля 4 и отвечает за авторизацию, роли и блокировку.
