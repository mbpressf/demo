import os
import random
import tkinter as tk
from tkinter import messagebox, simpledialog, ttk

from PIL import Image, ImageTk

from config import (
    APP_COMPANY,
    AUTH_ERROR_TEXT,
    AUTH_SUCCESS_TEXT,
    BLOCKED_TEXT,
    DEFAULT_NEW_USER_PASSWORD,
)
from entities.user_manager import UserManager

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
IMAGE_DIR = os.path.join(BASE_DIR, "images")


class CaptchaDialog(tk.Toplevel):
    def __init__(self, master, on_result):
        super().__init__(master)
        self.title(f"{APP_COMPANY} - капча")
        self.geometry("320x370")
        self.minsize(300, 340)
        self.transient(master)
        self.grab_set()

        self.on_result = on_result
        self.selected_index = None
        self.positions = [0, 1, 2, 3]
        while self.positions == [0, 1, 2, 3]:
            random.shuffle(self.positions)

        self.images = self._load_images()
        self.buttons = []

        frame = ttk.Frame(self, padding=10)
        frame.pack(fill="both", expand=True)
        puzzle = ttk.Frame(frame)
        puzzle.pack(pady=(0, 8))

        for row in range(2):
            for col in range(2):
                index = row * 2 + col
                button = tk.Button(
                    puzzle,
                    width=120,
                    height=120,
                    command=lambda value=index: self.swap_fragment(value),
                )
                button.grid(row=row, column=col, padx=2, pady=2)
                self.buttons.append(button)

        ttk.Button(frame, text="Подтвердить", command=self.check).pack(fill="x", pady=4)
        ttk.Label(frame, text="Нажмите два фрагмента, чтобы поменять их местами").pack()
        self.draw()

    def _load_images(self):
        images = []
        for number in range(1, 5):
            path = os.path.join(IMAGE_DIR, f"{number}.png")
            if not os.path.exists(path):
                raise FileNotFoundError(f"Не найден файл капчи: images/{number}.png")
            image = Image.open(path).resize((120, 120), Image.LANCZOS)
            images.append(ImageTk.PhotoImage(image))
        return images

    def draw(self):
        for index, button in enumerate(self.buttons):
            button.configure(image=self.images[self.positions[index]])

    def swap_fragment(self, index):
        if self.selected_index is None:
            self.selected_index = index
            self.buttons[index].configure(relief="sunken")
            return

        first = self.selected_index
        self.positions[first], self.positions[index] = self.positions[index], self.positions[first]
        self.buttons[first].configure(relief="raised")
        self.selected_index = None
        self.draw()

    def check(self):
        self.on_result(self.positions == [0, 1, 2, 3])
        self.destroy()


class LoginWindow(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"Авторизация - {APP_COMPANY}")
        self.geometry("380x230")
        self.minsize(340, 220)

        frame = ttk.Frame(self, padding=18)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="Вход в систему").grid(row=0, column=0, columnspan=2, pady=(0, 12))

        ttk.Label(frame, text="Логин:").grid(row=1, column=0, sticky="e", padx=6, pady=6)
        self.login_entry = ttk.Entry(frame)
        self.login_entry.grid(row=1, column=1, sticky="ew", pady=6)

        ttk.Label(frame, text="Пароль:").grid(row=2, column=0, sticky="e", padx=6, pady=6)
        self.password_entry = ttk.Entry(frame, show="*")
        self.password_entry.grid(row=2, column=1, sticky="ew", pady=6)

        self.login_button = ttk.Button(frame, text="Войти", command=self.open_captcha)
        self.login_button.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(16, 0))

        frame.columnconfigure(1, weight=1)
        self.bind("<Return>", lambda _event: self.open_captcha())
        self.login_entry.focus_set()

    def open_captcha(self):
        login = self.login_entry.get().strip()
        password = self.password_entry.get().strip()
        if not login or not password:
            messagebox.showwarning("Внимание", "Заполните обязательные поля Логин и Пароль")
            return
        CaptchaDialog(self, lambda captcha_ok: self.finish_login(login, password, captcha_ok))

    def finish_login(self, login, password, captcha_ok):
        try:
            result = UserManager.authenticate(login, password, captcha_ok)
        except Exception as exc:
            messagebox.showerror("Ошибка БД", str(exc))
            return

        if result == "blocked":
            messagebox.showerror("Блокировка", BLOCKED_TEXT)
            return
        if result == "fail":
            messagebox.showerror("Ошибка", AUTH_ERROR_TEXT)
            return

        messagebox.showinfo("Успех", AUTH_SUCCESS_TEXT)
        self.destroy()
        if result == "admin":
            AdminWindow().mainloop()
        else:
            UserDesktopWindow(login).mainloop()


class AdminWindow(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"Администратор - {APP_COMPANY}")
        self.geometry("680x430")
        self.minsize(560, 340)

        frame = ttk.Frame(self, padding=10)
        frame.pack(fill="both", expand=True)

        self.table = ttk.Treeview(frame, columns=("login", "role", "status"), show="headings")
        self.table.heading("login", text="Логин")
        self.table.heading("role", text="Роль")
        self.table.heading("status", text="Статус")
        self.table.column("login", width=220)
        self.table.column("role", width=120)
        self.table.column("status", width=150)
        self.table.pack(fill="both", expand=True)

        buttons = ttk.Frame(frame)
        buttons.pack(fill="x", pady=(10, 0))
        ttk.Button(buttons, text="Добавить пользователя", command=self.add_user).pack(side="left", padx=(0, 6))
        ttk.Button(buttons, text="Изменить роль", command=self.change_role).pack(side="left", padx=6)
        ttk.Button(buttons, text="Разблокировать", command=self.unblock_user).pack(side="left", padx=6)
        ttk.Button(buttons, text="Выход", command=self.destroy).pack(side="right")

        self.reload_users()

    def selected_login(self):
        selected = self.table.selection()
        if not selected:
            messagebox.showwarning("Внимание", "Выберите пользователя в таблице")
            return None
        return self.table.item(selected[0])["values"][0]

    def reload_users(self):
        for item in self.table.get_children():
            self.table.delete(item)
        for user in UserManager.list_users():
            status = "Заблокирован" if user.is_blocked else "Активен"
            self.table.insert("", "end", values=(user.login, user.role, status))

    def add_user(self):
        login = simpledialog.askstring("Новый пользователь", "Введите логин:")
        if login is None:
            return
        login = login.strip()
        if not login:
            messagebox.showwarning("Внимание", "Логин не может быть пустым")
            return
        try:
            created = UserManager.add_user(login)
        except Exception as exc:
            messagebox.showerror("Ошибка БД", str(exc))
            return
        if not created:
            messagebox.showerror("Ошибка", "Пользователь с указанным логином уже существует")
            return
        messagebox.showinfo("Успех", f"Пользователь добавлен. Пароль: {DEFAULT_NEW_USER_PASSWORD}")
        self.reload_users()

    def change_role(self):
        login = self.selected_login()
        if login is None:
            return
        role = simpledialog.askstring("Изменение роли", "Введите роль: admin или user", initialvalue="user")
        if role not in ("admin", "user"):
            messagebox.showwarning("Внимание", "Допустимые роли: admin, user")
            return
        UserManager.set_role(login, role)
        self.reload_users()

    def unblock_user(self):
        login = self.selected_login()
        if login is None:
            return
        UserManager.unblock(login)
        messagebox.showinfo("Успех", "Пользователь разблокирован")
        self.reload_users()


class UserDesktopWindow(tk.Tk):
    def __init__(self, login):
        super().__init__()
        self.title(f"Рабочий стол - {APP_COMPANY}")
        self.geometry("420x220")
        self.minsize(360, 200)

        frame = ttk.Frame(self, padding=20)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text=f"Добро пожаловать, {login}!").pack(pady=(20, 12))
        ttk.Label(frame, text="Роль: Пользователь").pack(pady=(0, 18))
        ttk.Button(frame, text="Выход", command=self.destroy).pack()
