# Модуль 4. Приложение авторизации

Приложение для варианта 5: `ООО "Кофейня Темная материя"`.

## Запуск

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python main.py
```

Перед запуском создайте БД `V5` и выполните:

```bash
psql -h localhost -p 5433 -U postgres -d V5 -f ../M2_База_данных/create_db.sql
psql -h localhost -p 5433 -U postgres -d V5 -f ../M2_База_данных/insert_data.sql
```

Приложение само пробует `5432`, затем `5433`. Если PostgreSQL не подключится, включится локальный режим.
В локальном режиме вход такой же: `admin` / `admin`.

Первый вход: `admin` / `admin`.
