# Модуль 2

1. Создать базу данных `V5`.
2. Выполнить `create_db.sql`.
3. Выполнить `insert_data.sql`.
4. Проверить импорт заказчиков:

```sql
SELECT id, name, inn, address, phone, is_seller, is_buyer
FROM customers
ORDER BY id;
```

Файл `insert_data.sql` содержит данные из `Заказчики.json`, заказ покупателя, продукцию, материалы и спецификацию изделия.
