-- Вариант 5. Модуль 2: загрузка данных.

BEGIN;

INSERT INTO customers (id, name, inn, address, phone, is_seller, is_buyer) VALUES
('000000000', 'ООО "Кофейня Темная материя"', NULL, 'адрес не указан в приложении', NULL, TRUE, FALSE),
('000000001', 'ООО "Поставка"', NULL, 'г.Пятигорск', '+79198634592', TRUE, TRUE),
('000000002', 'ООО "Кинотеатр Квант"', '26320045123', 'г. Железноводск, ул. Мира, 123', '+79884581555', TRUE, FALSE),
('000000008', 'ООО "Новый JDTO"', '26320045111', 'г. Железноводсу', '+79884581555', TRUE, FALSE),
('000000003', 'ООО "Ромашка"', '4140784214', 'г. Омск, ул. Строителей, 294', '+79882584546', FALSE, TRUE),
('000000009', 'ООО "Ипподром"', '5874045632', 'г. Уфа, ул. Набережная,  37', '+79627486389', TRUE, TRUE),
('000000010', 'ООО "Ассоль"', '2629011278', 'г. Калуга, ул. Пушкина, 94', '+79184572398', FALSE, TRUE);

-- Цены материалов взяты из "Расчет стоимости продукции.xlsx",
-- чтобы контрольный расчет себестоимости совпал с приложением: 132.75.
INSERT INTO materials (code, name, unit, price) VALUES
('НФ-00000009', 'Американо', 'шт', 220.00),
('НФ-00000010', 'Сироп "Имбирный пряник"', 'кг', 550.00),
('НФ-00000011', 'Взбитые сливки', 'кг', 250.00);

INSERT INTO products (code, name, unit, price) VALUES
('НФ-00000001', 'Раф "Имбирный пряник" 400г.', 'шт', 450.00),
(NULL, 'Раф "Черный лес" 300г.', 'шт', 440.00),
(NULL, 'Эспрессо 450г.', 'шт', 320.00),
(NULL, 'Латте "Ваниль" 250г.', 'шт', 210.00);

INSERT INTO specifications (product_id, material_id, quantity)
SELECT p.id, m.id, v.quantity
FROM (
    VALUES
        ('Раф "Имбирный пряник" 400г.', 'Американо', 0.150::NUMERIC),
        ('Раф "Имбирный пряник" 400г.', 'Сироп "Имбирный пряник"', 0.045::NUMERIC),
        ('Раф "Имбирный пряник" 400г.', 'Взбитые сливки', 0.300::NUMERIC)
) AS v(product_name, material_name, quantity)
JOIN products p ON p.name = v.product_name
JOIN materials m ON m.name = v.material_name;

INSERT INTO orders (id, order_number, order_date, executor_id, customer_id, total_amount)
VALUES (1, '1', DATE '2025-06-09', '000000000', '000000010', 8670.00);

INSERT INTO order_items (order_id, product_id, quantity, unit, price, subtotal)
SELECT 1, p.id, v.quantity, 'шт', v.price, v.quantity * v.price
FROM (
    VALUES
        ('Раф "Имбирный пряник" 400г.', 5, 450.00::NUMERIC),
        ('Раф "Черный лес" 300г.', 4, 440.00::NUMERIC),
        ('Эспрессо 450г.', 8, 320.00::NUMERIC),
        ('Латте "Ваниль" 250г.', 10, 210.00::NUMERIC)
) AS v(product_name, quantity, price)
JOIN products p ON p.name = v.product_name;

COMMIT;
