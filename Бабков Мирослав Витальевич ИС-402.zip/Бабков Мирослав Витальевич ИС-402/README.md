# Решение варианта 5

Вариант: `В5_КОД 09.02.07-5-2026-БУ`  
Заказчик приложения: `ООО "Кофейня Темная материя"`  
СУБД: PostgreSQL  
Приложение: Python + Tkinter

## Состав

| Папка | Содержание |
| --- | --- |
| `M1_ER_диаграмма` | ER-диаграмма в PDF |
| `M2_База_данных` | `create_db.sql`, `insert_data.sql`, скриншот таблицы `customers` |
| `M3_Запрос` | SQL-запрос расчета стоимости заказа и скриншот результата |
| `M4_Приложение` | приложение авторизации, капча-пазл, администрирование пользователей |
| `M5_Документация` | проектная документация |

## Быстрый запуск SQL

Самый простой вариант для экзамена:

1. В pgAdmin подключиться к базе `postgres`.
2. Открыть Query Tool и выполнить `00_create_database.sql`.
3. Переключиться на базу `V5`.
4. Открыть Query Tool и выполнить `01_exam_v5_all_queries.sql`.

После этого таблицы, данные и итоговый запрос будут готовы.

Альтернативный запуск через терминал:

```bash
createdb -h localhost -p 5433 -U postgres V5
psql -h localhost -p 5433 -U postgres -d V5 -f M2_База_данных/create_db.sql
psql -h localhost -p 5433 -U postgres -d V5 -f M2_База_данных/insert_data.sql
psql -h localhost -p 5433 -U postgres -d V5 -f M3_Запрос/module3_query.sql
```

Если база уже существует:

```bash
dropdb -h localhost -p 5433 -U postgres V5
createdb -h localhost -p 5433 -U postgres V5
```

## Быстрый запуск приложения

```bash
cd M4_Приложение
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python main.py
```

Логин администратора: `admin`  
Пароль администратора: `admin`

Параметры подключения к PostgreSQL лежат в `M4_Приложение/config.py`. По умолчанию используются:

| Параметр | Значение |
| --- | --- |
| host | `localhost` |
| port | `5433` |
| database | `V5` |
| user | `postgres` |
| password | `87654321` |

На экзамене при другом пароле или порте достаточно поправить `config.py` или задать переменные окружения `PGHOST`, `PGPORT`, `PGDATABASE`, `PGUSER`, `PGPASSWORD`.

## Контрольный результат модуля 3

Материальная себестоимость одной позиции `Раф "Имбирный пряник" 400г.`:

`0.15 * 220 + 0.045 * 550 + 0.3 * 250 = 132.75`

В заказе 5 штук:

`5 * 132.75 = 663.75`

Товарная сумма заказа из файла `Заказ покупателя.xlsx`: `8670.00`.
