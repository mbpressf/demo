# RedOS: возможные ошибки и что делать

## Правильный порядок

1. Распаковать ZIP.
2. В pgAdmin создать базу `V5`.
3. В базе `V5` выполнить `01_exam_v5_all_queries.sql`.
4. Перейти в приложение:

```bash
cd M4_Приложение
chmod +x run_redos.sh
./run_redos.sh
```

Приложение сначала пробует PostgreSQL. Если подключение не получилось, оно откроется в локальном режиме. Вход тот же:

```text
admin
admin
```

Если `run_redos.sh` не разрешают запускать:

```bash
cd M4_Приложение
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python check_redos.py
python main.py
```

## Ошибка: Connection refused

Пример:

```text
connection to server at localhost, port 5432/5433 failed: Connection refused
```

Причина: PostgreSQL не запущен на этом порту.

Что делать:

```bash
pg_isready -h localhost -p 5432
pg_isready -h localhost -p 5433
```

Если администратор сказал другой порт:

```bash
export PGPORT=ВАШ_ПОРТ
```

## Ошибка: database "V5" does not exist

Причина: база `V5` не создана.

Что делать в pgAdmin:

```text
Databases -> Create -> Database -> V5 -> Save
```

Потом открыть Query Tool именно в базе `V5` и выполнить:

```text
01_exam_v5_all_queries.sql
```

## Ошибка: password authentication failed

Причина: пароль PostgreSQL другой.

Что делать:

```bash
export PGPASSWORD='ваш_пароль'
```

Потом снова:

```bash
python check_redos.py
python main.py
```

## Ошибка: no module named tkinter

Причина: в RedOS не установлен пакет Tkinter.

Что делать: попросить администратора поставить пакет:

```bash
sudo dnf install python3-tkinter
```

Если sudo нельзя, это должен сделать администратор площадки.

## PostgreSQL не подключился, но приложение открылось

Это допустимый запасной режим. База и SQL уже проверяются отдельно через pgAdmin, а модуль 4 можно показать в локальном режиме с тем же входом `admin/admin`.

## Ошибка при установке Python-пакетов

Попробовать:

```bash
python -m pip install --upgrade pip setuptools wheel
pip install -r requirements.txt
```

Если не помогает, попросить администратора проверить доступ pip к интернету.

## Ошибка: images/1.png not found

Причина: приложение запущено не из папки `M4_Приложение` или не распакованы картинки.

Что делать:

```bash
cd M4_Приложение
ls images
python main.py
```

В папке `images` должны быть `1.png`, `2.png`, `3.png`, `4.png`.

## Если случайно задан PGPORT=5433

Если приложение пробует только `5433`, а PostgreSQL на `5432`, сбросить переменную:

```bash
unset PGPORT
```

Или указать явно:

```bash
export PGPORT=5432
```

## Контроль готовности

Перед запуском приложения:

```bash
cd M4_Приложение
source .venv/bin/activate
python check_redos.py
```

Если в конце написано:

```text
[OK] Environment is ready...
```

значит можно запускать приложение.
