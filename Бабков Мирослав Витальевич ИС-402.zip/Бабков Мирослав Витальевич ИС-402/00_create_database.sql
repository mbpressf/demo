-- ВНИМАНИЕ ДЛЯ pgAdmin:
-- CREATE DATABASE не выполняется внутри транзакции.
-- Если pgAdmin показывает ошибку "CREATE DATABASE не может выполняться внутри блока транзакции",
-- создайте базу V5 вручную через интерфейс:
-- Databases -> Create -> Database -> Database: V5 -> Save.
--
-- Этот файл нужен только если Query Tool работает с включенным Auto commit.
-- Подключаться нужно к служебной базе postgres, не к V5.

SELECT pg_terminate_backend(pid)
FROM pg_stat_activity
WHERE datname = 'V5'
  AND pid <> pg_backend_pid();

DROP DATABASE IF EXISTS "V5";
CREATE DATABASE "V5";
