﻿-- Вариант 5. Полный SQL для экзамена.
-- Запускать в Query Tool, подключившись к базе V5.
-- Скрипт создает структуру, загружает данные и выводит контрольные результаты.

-- Вариант 5. Модуль 2: создание структуры базы данных PostgreSQL.
-- Простая схема в 3НФ, близкая к примеру решения.

DROP TABLE IF EXISTS order_items CASCADE;
DROP TABLE IF EXISTS orders CASCADE;
DROP TABLE IF EXISTS specifications CASCADE;
DROP TABLE IF EXISTS products CASCADE;
DROP TABLE IF EXISTS materials CASCADE;
DROP TABLE IF EXISTS users CASCADE;
DROP TABLE IF EXISTS customers CASCADE;

CREATE TABLE customers (
    id VARCHAR(20) PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    inn VARCHAR(12),
    address VARCHAR(255),
    phone VARCHAR(20),
    is_seller BOOLEAN NOT NULL DEFAULT FALSE,
    is_buyer BOOLEAN NOT NULL DEFAULT FALSE,
    CHECK (is_seller OR is_buyer)
);

CREATE TABLE materials (
    id SERIAL PRIMARY KEY,
    code VARCHAR(20) UNIQUE,
    name VARCHAR(255) NOT NULL UNIQUE,
    unit VARCHAR(20) NOT NULL,
    price NUMERIC(12, 2) NOT NULL CHECK (price >= 0)
);

CREATE TABLE products (
    id SERIAL PRIMARY KEY,
    code VARCHAR(20) UNIQUE,
    name VARCHAR(255) NOT NULL UNIQUE,
    unit VARCHAR(20) NOT NULL,
    price NUMERIC(12, 2) NOT NULL CHECK (price >= 0)
);

CREATE TABLE specifications (
    product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    material_id INTEGER NOT NULL REFERENCES materials(id) ON DELETE RESTRICT,
    quantity NUMERIC(12, 3) NOT NULL CHECK (quantity > 0),
    PRIMARY KEY (product_id, material_id)
);

CREATE TABLE orders (
    id SERIAL PRIMARY KEY,
    order_number VARCHAR(30) NOT NULL,
    order_date DATE NOT NULL,
    executor_id VARCHAR(20) REFERENCES customers(id),
    customer_id VARCHAR(20) NOT NULL REFERENCES customers(id),
    total_amount NUMERIC(12, 2) NOT NULL CHECK (total_amount >= 0)
);

CREATE TABLE order_items (
    order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    unit VARCHAR(20) NOT NULL,
    price NUMERIC(12, 2) NOT NULL CHECK (price >= 0),
    subtotal NUMERIC(12, 2) NOT NULL CHECK (subtotal >= 0),
    PRIMARY KEY (order_id, product_id),
    CHECK (subtotal = quantity * price)
);

CREATE TABLE users (
    login VARCHAR(50) PRIMARY KEY,
    password_hash VARCHAR(120) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'user',
    is_blocked BOOLEAN NOT NULL DEFAULT FALSE,
    failed_attempts INTEGER NOT NULL DEFAULT 0,
    CHECK (role IN ('admin', 'user')),
    CHECK (failed_attempts >= 0)
);


-- Вариант 5. Модуль 2: загрузка данных.

BEGIN;

INSERT INTO customers (id, name, inn, address, phone, is_seller, is_buyer) VALUES
('000000000', 'ООО "Кофейня Темная материя"', NULL, 'адрес не указан в приложении', NULL, TRUE, FALSE),
('000000001', 'ООО "Поставка"', NULL, 'г.Пятигорск', '+79198634592', TRUE, TRUE),
('000000002', 'ООО "Кинотеатр Квант"', '26320045123', 'г. Железноводск, ул. Мира, 123', '+79884581555', TRUE, FALSE),
('000000008', 'ООО "Новый JDTO"', '26320045111', 'г. Железноводсу', '+79884581555', TRUE, FALSE),
('000000003', 'ООО "Ромашка"', '4140784214', 'г. Омск, ул. Строителей, 294', '+79882584546', FALSE, TRUE),
('000000009', 'ООО "Ипподром"', '5874045632', 'г. Уфа, ул. Набережная,  37', '+79627486389', TRUE, TRUE),
('000000010', 'ООО "Ассоль"', '2629011278', 'г. Калуга, ул. Пушкина, 94', '+79184572398', FALSE, TRUE);

-- Цены материалов взяты из "Расчет стоимости продукции.xlsx",
-- чтобы контрольный расчет себестоимости совпал с приложением: 132.75.
INSERT INTO materials (code, name, unit, price) VALUES
('НФ-00000009', 'Американо', 'шт', 220.00),
('НФ-00000010', 'Сироп "Имбирный пряник"', 'кг', 550.00),
('НФ-00000011', 'Взбитые сливки', 'кг', 250.00);

INSERT INTO products (code, name, unit, price) VALUES
('НФ-00000001', 'Раф "Имбирный пряник" 400г.', 'шт', 450.00),
(NULL, 'Раф "Черный лес" 300г.', 'шт', 440.00),
(NULL, 'Эспрессо 450г.', 'шт', 320.00),
(NULL, 'Латте "Ваниль" 250г.', 'шт', 210.00);

INSERT INTO specifications (product_id, material_id, quantity)
SELECT p.id, m.id, v.quantity
FROM (
    VALUES
        ('Раф "Имбирный пряник" 400г.', 'Американо', 0.150::NUMERIC),
        ('Раф "Имбирный пряник" 400г.', 'Сироп "Имбирный пряник"', 0.045::NUMERIC),
        ('Раф "Имбирный пряник" 400г.', 'Взбитые сливки', 0.300::NUMERIC)
) AS v(product_name, material_name, quantity)
JOIN products p ON p.name = v.product_name
JOIN materials m ON m.name = v.material_name;

INSERT INTO orders (id, order_number, order_date, executor_id, customer_id, total_amount)
VALUES (1, '1', DATE '2025-06-09', '000000000', '000000010', 8670.00);

INSERT INTO order_items (order_id, product_id, quantity, unit, price, subtotal)
SELECT 1, p.id, v.quantity, 'шт', v.price, v.quantity * v.price
FROM (
    VALUES
        ('Раф "Имбирный пряник" 400г.', 5, 450.00::NUMERIC),
        ('Раф "Черный лес" 300г.', 4, 440.00::NUMERIC),
        ('Эспрессо 450г.', 8, 320.00::NUMERIC),
        ('Латте "Ваниль" 250г.', 10, 210.00::NUMERIC)
) AS v(product_name, quantity, price)
JOIN products p ON p.name = v.product_name;

COMMIT;


-- Проверка 1: заказчики загружены.
SELECT id, name, inn, address, phone, is_seller, is_buyer
FROM customers
ORDER BY id;

-- Проверка 2: спецификация продукции.
SELECT
    p.name AS product_name,
    m.name AS material_name,
    s.quantity,
    m.unit,
    m.price,
    s.quantity * m.price AS material_sum
FROM specifications s
JOIN products p ON p.id = s.product_id
JOIN materials m ON m.id = s.material_id
ORDER BY p.name, m.name;

-- Модуль 3: итоговая полная материальная стоимость заказа покупателя.
-- Вариант 5. Модуль 3: расчет полной материальной стоимости заказа покупателя.

WITH product_material_cost AS (
    SELECT
        s.product_id,
        SUM(s.quantity * m.price) AS material_cost_per_unit
    FROM specifications s
    JOIN materials m ON m.id = s.material_id
    GROUP BY s.product_id
),
order_material_cost AS (
    SELECT
        o.id AS order_id,
        o.order_number,
        o.order_date,
        c.name AS customer_name,
        p.name AS product_name,
        oi.quantity AS product_quantity,
        oi.subtotal AS product_sale_amount,
        COALESCE(pmc.material_cost_per_unit, 0) AS material_cost_per_unit,
        oi.quantity * COALESCE(pmc.material_cost_per_unit, 0) AS material_cost_total
    FROM orders o
    JOIN customers c ON c.id = o.customer_id
    JOIN order_items oi ON oi.order_id = o.id
    JOIN products p ON p.id = oi.product_id
    LEFT JOIN product_material_cost pmc ON pmc.product_id = p.id
)
SELECT
    order_id,
    order_number,
    order_date,
    customer_name,
    SUM(product_sale_amount) AS order_sale_total,
    SUM(material_cost_total) AS order_material_total
FROM order_material_cost
GROUP BY order_id, order_number, order_date, customer_name
ORDER BY order_id;

-- Контроль:
-- 0.15*220 + 0.045*550 + 0.3*250 = 132.75
-- 5 * 132.75 = 663.75


-- Ожидаемый итог:
-- order_sale_total = 8670.00
-- order_material_total = 663.75
